//
//  SelectedIssueCollectionViewCell.swift
//  HealthCard
//
//  Created by Pratik Khopkar on 13/04/22.
//

import UIKit

class SelectedIssueCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var viewRef: UIView!
    @IBOutlet weak var lblRef: UILabel!
    @IBOutlet weak var crossBtnRef: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
