//
//  ConsultSpecialityTableViewCell.swift
//  HealthCard
//
//  Created by Pratik Khopkar on 12/04/22.
//

import UIKit

class ConsultSpecialityTableViewCell: UITableViewCell {
    @IBOutlet weak var viewRef: UIView!
    @IBOutlet weak var lblRef: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
